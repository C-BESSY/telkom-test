import { useState } from 'react';
import './App.css';

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const sendMessage = () => {
    if (input.trim()) {
      const userMessage = input.trim();
      setMessages(prevMessages => [
        ...prevMessages,
        { user: 'You', text: userMessage }
      ]);

      // Simulate response from virtual assistant
      setTimeout(() => {
        const assistantResponse = `You said: "${userMessage}"`;
        setMessages(prevMessages => [
          ...prevMessages,
          { user: 'Virtual Assistant', text: assistantResponse }
        ]);
      }, 1000);

      setInput('');
    }
  };

  return (
    <div className="App">
      <div className="container">
        <div className="sidebar">
          <div className="sidebar-title">
            <h3>Chat</h3>
          </div>
          <div className="user-name">Virtual Assistant</div>
        </div>

        <div className="chat-box-container">
          <div className="chat-box">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`chat-message ${msg.user === 'You' ? 'user-message' : 'assistant-message'}`}
              >
                <strong>{msg.user}: </strong>{msg.text}
              </div>
            ))}
          </div>
          <div className="input-container">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              placeholder="Type a message"
            />
            <button onClick={sendMessage}>Send</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
